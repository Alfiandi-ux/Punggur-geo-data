# Indonesia Geo Data

Kumpulan data dan analisis geografi Indonesia untuk keperluan eksplorasi pribadi.

## Tentang Project

Deskripsikan di sini project ini tentang apa. Contoh:
> Kumpulan data batas administrasi, titik lokasi, dan visualisasi peta wilayah Indonesia.

## Struktur Folder

```
indonesia-geo-data/
├── data/
│   ├── raw/          # data mentah (shapefile, geojson, csv asli, belum diubah)
│   └── processed/    # data hasil pembersihan/olahan, siap dipakai
├── scripts/          # kode Python/R untuk pemrosesan data
├── notebooks/        # Jupyter notebooks untuk eksplorasi & visualisasi
├── docs/             # catatan, sumber data, dokumentasi tambahan
├── README.md
└── .gitignore
```

## Sumber Data

| Dataset | Sumber | Tanggal Akses | Format |
|---|---|---|---|
| Titik lokasi Kec. Punggur, Lampung Tengah | Wikipedia, kodepos.co.id | 2026-08-10 | GeoJSON (Point) |
| _tambahkan dataset lain di sini_ | | | |

Lihat detail profil di [`docs/profil_punggur.md`](docs/profil_punggur.md).

## Cara Pakai

```bash
git clone https://github.com/username/indonesia-geo-data.git
cd indonesia-geo-data
pip install -r requirements.txt
```

Buka notebook di folder `notebooks/` untuk mulai eksplorasi.

## Tools

- Python — `geopandas`, `shapely`, `folium`
- Jupyter Notebook

## Lisensi

Data pribadi/eksplorasi. Sesuaikan lisensi data sesuai sumber aslinya.
